module Main {
    requires Helpers.LDAP;
    requires Helpers.Local;
}