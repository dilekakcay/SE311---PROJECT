module Helpers.LDAP {
    exports Helpers.LDAP.code;
}