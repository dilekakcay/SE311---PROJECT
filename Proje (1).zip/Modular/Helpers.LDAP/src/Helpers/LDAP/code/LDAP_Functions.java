package Helpers.LDAP.code;

public class LDAP_Functions {

    public void print() {
        System.out.println("LDAP works!");
    }
}
