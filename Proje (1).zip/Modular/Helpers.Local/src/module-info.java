module Helpers.Local {
    exports Helpers.Local.code;
}