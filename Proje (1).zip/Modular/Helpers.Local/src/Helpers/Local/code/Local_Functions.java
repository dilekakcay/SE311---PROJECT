package Helpers.Local.code;

public class Local_Functions {

    public void getuid() {
        System.out.println("Local works!");
    }
}
